package com.example.prob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProbApplication.class, args);
	}

}
