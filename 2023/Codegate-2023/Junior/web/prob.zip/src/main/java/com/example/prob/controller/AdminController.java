package com.example.prob.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Controller
@RequestMapping("/admin/{menu}")
public class AdminController {

    @GetMapping({ "/external" })
    public ResponseEntity<String> external(@RequestParam("url") String url) throws IOException {
        String scheme = url.substring(0, url.indexOf(":"));
        if (scheme.matches("(?i)file|(?i)url")) {
            return ResponseEntity.ok().body("filtered");
        } else {
            String responseBody = requestContents(url);
            return ResponseEntity.ok().body(responseBody);
        }
    }

    public static String requestContents(String url) throws IOException {
        URL requestURL = new URL(url);
        BufferedReader reader = new BufferedReader(new InputStreamReader(requestURL.openStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }
}
