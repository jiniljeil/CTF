def stringToJson(status_code: int, message: str, data=None) -> dict:
    if status_code not in [200, 201, 400, 404]:
        return {'status': '500', 'message': 'Server Internal Error', 'data': 'none'}

    if data is not None:
        return {'status': status_code, 'message': f'{message}', 'data': data if data != "" else "none"}

    return {'status': status_code, 'message': f'{message}', 'data': 'none'}
