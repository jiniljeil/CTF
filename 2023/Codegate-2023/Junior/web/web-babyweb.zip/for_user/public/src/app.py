from application import create_app
from application.config import productConfig  # devConfig

app = create_app(config=productConfig)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080)
