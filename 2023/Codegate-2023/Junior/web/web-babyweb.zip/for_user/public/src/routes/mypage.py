import os
from flask import Blueprint, render_template, session, make_response, redirect, url_for, request
from werkzeug.exceptions import RequestEntityTooLarge

from controller.todoHandler import TodoHandler
from controller.fileHandler import FileHandler
from utility.fileUtility import FILE_FORMAT
from utility.customException import CustomException

NAME = 'mypage'
bp = Blueprint(NAME, __name__, template_folder='templates', url_prefix='/' + NAME)

todo_handler = TodoHandler()
file_handler = FileHandler()


@bp.before_request
def user_valid():
    if "username" not in session or "uuid" not in session:
        return redirect(url_for("main.logout"))


@bp.get('')
def mypage():
    try:
        status_code, message, data = tuple(todo_handler.get_todo_by_uuid(uuid=session["uuid"]).values())

        if status_code == 200 and message == "OK" and data != "none":
            return render_template('mypage.html', title="mypage", session=session, todolist=data)
        else:
            CustomException(error_message="Bad Request")
    except:
        resp = make_response(redirect(url_for("main.logout")))
        return resp


@bp.get('/read/<string:todo_uid>')
def todoRead(todo_uid):
    try:
        if todo_uid == "":
            return redirect(url_for("mypage.mypage"))

        status_code, message, data = tuple(todo_handler.get_todo_by_todo_uid(uuid=session["uuid"], todo_uid=todo_uid).values())

        filename: str = ""

        if data[0] != "":
            _, __, file = tuple(file_handler.get_file_by_file_uid(uuid=session["uuid"], todo_uid=todo_uid, file_uid=data[0]).values())

            if _ != 200 or __ != "OK" or file[0] == "":
                raise CustomException(error_message="Bad Request")

            filename = file[0]

        if status_code == 200 and message == "OK" and data != "none":
            return render_template('read.html', title="todo-read", session=session, todo_uid=todo_uid, todolist=data, filename=filename if filename != "" else "")
        else:
            raise CustomException(error_message="Bad Request")

    except Exception as e:
        resp = make_response(redirect(url_for("mypage.mypage")))
        return resp


@bp.post('/upload/<string:todo_uid>')
def fileUpload(todo_uid):
    status_code: int = 0
    todolist = None
    try:
        if todo_uid == "":
            raise CustomException(error_message="Invalid todo uid")

        files = request.files["file"]

        if files.filename == "" or not os.path.splitext(files.filename)[1] in FILE_FORMAT.ALLOW_FILE_MIMETYPE:
            # or files.mimetype != "application/zip" or files.mimetype != "text/plain"
            files = None
            raise CustomException(error_message="Invalid file")

        status_code, message, data = tuple(todo_handler.get_todo_by_todo_uid(uuid=session["uuid"], todo_uid=todo_uid).values())
        todolist = data

        if status_code != 200 or message != "OK" or data == "none":
            raise CustomException(error_message="Invalid user")

        status_code, message, data = tuple(file_handler.create_file(uuid=session["uuid"], todo_uid=todo_uid, filename=files.filename, files=files).values())

        if status_code == 201 and message == "Created" and data != "none":
            return redirect(url_for("mypage.todoRead", todo_uid=todo_uid))
        else:
            raise CustomException(error_message="Invalid access")

    except RequestEntityTooLarge:
        resp = make_response(render_template('mypage.html', title="mypage", session=session, error="File Too Large", todolist=todolist))
        resp.status_code = 400
        return resp

    except Exception as e:
        resp = make_response(render_template('mypage.html', title="mypage", session=session, error=e, todolist=todolist))
        resp.status_code = status_code if status_code != 0 else 400
        return resp


# TODO
@bp.get('/download/<string:todo_uid>/<string:filename>')
def fileDownload(todo_uid, filename):
    print(todo_uid, filename)
    return redirect(url_for("mypage.mypage"))


@bp.get("/rss/<string:todo_uid>/<string:filename>")
def rss(todo_uid, filename):
    try:
        if filename == "":
            raise CustomException(error_message="Bad Request")

        status_code, message, data = tuple(file_handler.get_file_by_filename(filename=filename).values())

        if status_code != 200 or message != "OK":
            raise CustomException(error_message="Bad Request")

        status_code, message, data = tuple(todo_handler.get_rss_by_todo_uid(uuid=session["uuid"], todo_uid=todo_uid).values())

        if status_code == 200 and message == "OK" and data != "none":
            resp = make_response()
            resp.headers["Content-Type"] = "text/xml"
            resp.status_code = status_code
            resp.data = data
            return resp
        else:
            raise CustomException(error_message="Bad Request")
    except:
        resp = make_response(render_template("index.html", title="account", session=session, error="Bad Request"))
        resp.status_code = 400
        return resp
