import os, sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from os.path import abspath
from flask import Flask, g, render_template
from werkzeug.middleware.proxy_fix import ProxyFix

from utility.models import ToDoDB


def create_app(config=None):
    app = Flask(__name__, static_folder=f"{abspath('static')}", template_folder=f"{abspath('templates')}")
    app.wsgi_app = ProxyFix(app.wsgi_app)
    app.config.from_object(config)

    # route initialization
    from routes import main, account, mypage, todo
    app.register_blueprint(main.bp)
    app.register_blueprint(account.bp)
    app.register_blueprint(mypage.bp)
    app.register_blueprint(todo.bp)

    app.app_context().push()

    ToDoDB.init_app(app)
    ToDoDB.app = app

    @app.before_request
    def before_request():
        g.babyweb = ToDoDB.session

    @app.teardown_request
    def teardown_request(exception):
        if hasattr(g, 'babyweb'):
            g.babyweb.close()

    @app.errorhandler(400)
    def BadRequest(error):
        return render_template('error/400.html'), 400

    @app.errorhandler(404)
    def NotFound(error):
        return render_template('error/404.html'), 404

    @app.errorhandler(405)
    def NotFound(error):
        return render_template('error/404.html'), 405

    @app.errorhandler(500)
    def ServerInternalError(error):
        return render_template('error/500.html'), 500

    return app
