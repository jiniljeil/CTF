from flask import Blueprint, session, make_response, render_template, redirect, url_for

NAME = 'main'
bp = Blueprint(NAME, __name__, template_folder='templates', url_prefix='/')


@bp.get('/')
def index():
    if "username" in session and "uuid" in session:
        return render_template('index.html', title='To-Do Services', session=session)

    return render_template('index.html', title='To-Do Services')


@bp.get('/logout')
def logout():
    session.pop("username", None)
    session.pop("uuid", None)

    resp = make_response(render_template('account.html', title="account", error="logout success"))
    resp.set_cookie(key='uuid', value='', expires=0)
    resp.set_cookie(key='session', value='', expires=0)
    resp.status_code = 200
    return resp
