from flask import Blueprint, render_template, request, session, make_response, redirect, url_for

from utility.customException import CustomException
from controller.todoHandler import TodoHandler

NAME = 'todo'
bp = Blueprint(NAME, __name__, url_prefix='/' + NAME)

todo_handler = TodoHandler()


@bp.before_request
def user_valid():
    if "username" not in session or "uuid" not in session:
        return redirect(url_for("main.logout"))


@bp.get('')
def todo():
    return render_template('todo.html', title="todo", session=session)


@bp.post('/make/<string:user_identifier>')
def todo_make(user_identifier):
    status_code: int = 0
    try:
        if user_identifier != session["uuid"]:
            raise CustomException(error_message="Invalid user")

        title, description, checklist_1, checklist_2, checklist_3, uuid = tuple(request.form.values())
        checklist = checklist_1.replace(",", "") + "," + checklist_2.replace(",", "") + "," + checklist_3.replace(",", "")

        if title == "" or description == "" or uuid == "":
            raise CustomException("Try again")

        if uuid != session["uuid"]:
            raise CustomException(error_message="Invalid user")

        status_code, message, data = tuple(todo_handler.create_todo(uuid=uuid, title=title, description=description, checklist=checklist).values())

        if status_code == 201 and message == "Created" and data == "none":
            resp = make_response(redirect(url_for("mypage.mypage")))
            return resp
        else:
            raise CustomException(f"{message}")

    except Exception as e:
        resp = make_response(render_template('todo.html', title="todo", error=e))
        resp.status_code = status_code if status_code != 0 else 400
        return resp
