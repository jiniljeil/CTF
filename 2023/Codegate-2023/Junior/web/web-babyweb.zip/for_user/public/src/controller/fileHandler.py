import os, zipfile, magic
from flask import g
from base64 import b64encode, b64decode
from uuid import uuid5, NAMESPACE_URL
from datetime import datetime
from time import time

from utility.models import userModel, todoModel, fileModel
from utility.fileUtility import FILE_FORMAT, FileValidation
from utility.httpUtility import stringToJson
from utility.customException import CustomException


class FileHandler(object):
    def __init__(self):
        self.selectData = None
        self.insertData = None

    def get_file_by_file_uid(self, uuid: str, todo_uid: str, file_uid: str) -> stringToJson:
        try:
            self.selectData = g.babyweb.query(
                userModel.uuid
            ).filter(
                userModel.uuid == uuid
            ).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            self.selectData = g.babyweb.query(
                todoModel.uuid, todoModel.todo_uid, todoModel.file_uid, todoModel.file_existed_check
            ).filter(
                todoModel.uuid == uuid, todoModel.todo_uid == todo_uid, todoModel.file_uid == file_uid, todoModel.file_existed_check == 1
            ).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            self.selectData = g.babyweb.query(
                fileModel.filename
            ).filter(
                fileModel.uuid == uuid, fileModel.todo_uid == todo_uid, fileModel.file_uid == file_uid
            ).first()

            if self.selectData:
                return stringToJson(status_code=200, message='OK', data=self.selectData)
            else:
                raise CustomException(error_message="Bad Request")
        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def get_file_by_filename(self, filename: str) -> stringToJson:
        try:
            self.selectData = g.babyweb.query(fileModel.filename).filter(
                fileModel.filename == filename
            ).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            return stringToJson(status_code=200, message='OK')
        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def create_file(self, uuid: str, todo_uid: str, filename: str, files) -> stringToJson:
        try:
            self.insertData = {"uuid": uuid, "todo_uid": todo_uid, "file_uid": "", "filename": "", "description": "", "path": ""}

            fileValid = FileValidation(uuid=self.insertData["uuid"], todo_uid=self.insertData["todo_uid"], filename=filename)
            fileValid.custom_secure_filename()

            filename = fileValid.get_custom_filename()

            self.insertData["file_uid"] = str(uuid5(namespace=NAMESPACE_URL, name=self.insertData['uuid'] + filename + str(time())))
            self.insertData["filename"] = filename
            self.insertData["description"] = "description"
            self.insertData["path"] = FILE_FORMAT.FILE_PATH

            g.babyweb.add(
                fileModel(
                    uuid=self.insertData["uuid"],
                    todo_uid=self.insertData["todo_uid"],
                    file_uid=self.insertData["file_uid"],
                    filename=self.insertData["filename"],
                    description=self.insertData["description"],
                    path=self.insertData["path"] + f"{uuid}/" + f"{todo_uid}/",
                    create_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )
            )

            g.babyweb.query(todoModel).filter(
                todoModel.todo_uid == self.insertData["todo_uid"]
            ).update(
                {"file_existed_check": 1}
            )

            g.babyweb.query(todoModel).filter(
                todoModel.todo_uid == self.insertData["todo_uid"]
            ).update(
                {"file_uid": self.insertData["file_uid"]}
            )

            g.babyweb.query(todoModel).filter(
                todoModel.todo_uid == self.insertData["todo_uid"]
            ).update(
                {"last_modified": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            )

            status_code = self.save_file(file=files, filename=self.insertData["filename"], uuid=self.insertData["uuid"], todo_uid=self.insertData["todo_uid"])

            if status_code != 200:
                raise CustomException(error_message="Bad Request")
        except:
            g.babyweb.rollback()
        else:
            g.babyweb.commit()
            return stringToJson(status_code=201, message='Created', data=self.insertData["file_uid"])

        return stringToJson(status_code=400, message='Bad Request')

    @staticmethod
    def save_file(file, filename: str, uuid: str, todo_uid: str) -> int:
        try:
            PATH = FILE_FORMAT.FILE_PATH + f"{uuid}/" + f"{todo_uid}/"
            if os.path.exists(PATH):
                file.save(PATH + filename)
            else:
                os.makedirs(PATH)
                file.save(PATH + filename)

            mime = [magic.from_file(PATH + filename, mime=True), magic.from_buffer(open(PATH + filename, "rb").read(2024)), magic.from_file(PATH + filename, mime=True)]

            if FILE_FORMAT.ALLOW_FILE_MIME[4] in mime:
                return 200

            if mime[0] in FILE_FORMAT.ALLOW_FILE_MIME or mime[1] in FILE_FORMAT.ALLOW_FILE_MIME or mime[2] in FILE_FORMAT.ALLOW_FILE_MIME:
                with zipfile.ZipFile(PATH + filename, "r") as zip_ref:
                    zip_ref.extractall(PATH)
                return 200
            else:
                os.remove(PATH)
                raise CustomException("ZIP ERROR")
        except:
            return 400
