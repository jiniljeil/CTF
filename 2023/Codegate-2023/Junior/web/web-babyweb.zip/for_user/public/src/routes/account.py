from flask import Blueprint, render_template, request, session, make_response, redirect, url_for
from base64 import b64encode
from datetime import datetime, timedelta

from controller.accountHandler import UserHandler
from utility.customException import CustomException

NAME = 'account'
bp = Blueprint(NAME, __name__, url_prefix='/' + NAME)

user_handler = UserHandler()


@bp.before_request
def duplicate_valid():
    if "username" in session and "uuid" in session:
        return redirect(url_for("main.index"))


@bp.get('')
def account_signin():
    return render_template('account.html', title="account")


@bp.post('/signin')
def signin():
    status_code: int = 0

    try:
        username, password = tuple(request.form.values())

        if (username == "" or password == "") or (len(username) > 30 or len(password) > 30):
            raise CustomException(error_message="username or password invalid")

        authorization = b64encode(f"{username},{password}".encode())

        status_code, message, data = tuple(user_handler.get_user_by_account_info(Authorization=authorization).values())

        if status_code == 200 and message == "OK" and data != "none":
            session["username"] = username
            session["uuid"] = data
            resp = make_response(redirect(url_for("main.index")))
            resp.set_cookie(key='uuid', value=data, expires=datetime.now() + timedelta(minutes=5), secure=None, httponly=True, path='/')
            return resp
        else:
            raise CustomException(error_message="username or password invalid")

    except Exception as e:
        resp = make_response(render_template('account.html', title="account", error=e))
        resp.status_code = status_code
        return resp


@bp.post('/signup')
def signup():
    status_code: int = 0

    try:
        username, password = tuple(request.form.values())

        if (username == "" or password == "") or (len(username) > 30 or len(password) > 30):
            raise CustomException(error_message="username or password invalid")

        authorization = b64encode(f"{username},{password}".encode())

        status_code, message, data = tuple(user_handler.create_user(Authorization=authorization).values())

        if status_code == 201 and message == "Success" and data == "none":
            resp = make_response(render_template('account.html', title="account", error=message))
            resp.status_code = status_code
            return resp
        else:
            raise CustomException(error_message=f"{message}")

    except Exception as e:
        resp = make_response(render_template('account.html', title="account", error=e))
        resp.status_code = status_code
        return resp
