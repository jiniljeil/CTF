from flask import g
from base64 import b64encode, b64decode
from uuid import uuid5, NAMESPACE_URL
from datetime import datetime
from time import time

from utility.models import userModel, todoModel, fileModel
from utility.httpUtility import stringToJson
from utility.xmlUtility import XMLUtilities
from utility.customException import CustomException


class TodoHandler(object):
    def __init__(self):
        self.selectData = None
        self.insertData = None
        self.updateData = None

    def get_todo_by_uuid(self, uuid: str) -> stringToJson:
        try:
            self.selectData = g.babyweb.query(userModel.uuid).filter(userModel.uuid == uuid).count()
            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            self.selectData = g.babyweb.query(
                todoModel.id, todoModel.todo_uid, todoModel.title, todoModel.last_modified, todoModel.create_time
            ).filter(
                todoModel.uuid == uuid
            ).all()

            return stringToJson(status_code=200, message='OK', data=self.selectData)

        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def get_todo_by_todo_uid(self, uuid: str, todo_uid: str) -> stringToJson:
        try:
            self.selectData = g.babyweb.query(userModel.uuid).filter(userModel.uuid == uuid).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            self.selectData = g.babyweb.query(
                todoModel.file_uid, todoModel.title, todoModel.description, todoModel.checklist, todoModel.file_existed_check, todoModel.last_modified, todoModel.create_time
            ).filter(
                todoModel.todo_uid == todo_uid
            ).first()

            return stringToJson(status_code=200, message='OK', data=self.selectData if self.selectData else None)
        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def get_rss_by_todo_uid(self, uuid: str, todo_uid: str) -> stringToJson:
        try:
            self.selectData = g.babyweb.query(userModel.uuid).filter(userModel.uuid == uuid).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            data: dict = {}

            self.selectData = g.babyweb.query(
                userModel.uuid, userModel.username
            ).filter(
                userModel.uuid == uuid
            ).first()

            data["uuid"], data["author"] = self.selectData

            self.selectData = g.babyweb.query(
                todoModel.todo_uid, todoModel.file_uid, todoModel.title, todoModel.description, todoModel.checklist, todoModel.last_modified, todoModel.create_time
            ).filter(
                todoModel.todo_uid == todo_uid
            ).first()

            data["todo_uid"], data["file_uid"], data["todo_title"], data["todo_description"], data["list"], data["last_modified"], data["create_time"] = self.selectData

            self.selectData = g.babyweb.query(
                fileModel.file_uid, fileModel.filename, fileModel.description, fileModel.create_time
            ).filter(
                fileModel.file_uid == data["file_uid"]
            ).first()

            data["file_uid"], data["file_name"], data["file_description"], data["file_create_time"] = self.selectData

            xmlutils = XMLUtilities()
            xmlutils.text2xml(data=data)
            rss = xmlutils.get_xml()

            if rss == "XML Parsing ERROR":
                raise CustomException(error_message="Bad Request")

            return stringToJson(status_code=200, message='OK', data=rss)
        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def create_todo(self, uuid: str, title: str, description: str, checklist: str) -> stringToJson:
        try:
            self.insertData = {
                "uuid": uuid, "todo_uid": "", "title": title, "description": description, "checklist": checklist, "file_existed_check": 0
            }

            self.selectData = g.babyweb.query(userModel.uuid).filter(userModel.uuid == self.insertData["uuid"]).count()

            if self.selectData < 1:
                raise CustomException(error_message="Bad Request")

            self.insertData["todo_uid"] = str(uuid5(namespace=NAMESPACE_URL, name=self.insertData['uuid'] + self.insertData['title'] + str(time())))

            g.babyweb.add(
                todoModel(
                    uuid=self.insertData["uuid"],
                    todo_uid=self.insertData["todo_uid"],
                    file_uid='',
                    title=self.insertData["title"],
                    description=self.insertData["description"],
                    checklist=self.insertData["checklist"],
                    file_existed_check=self.insertData["file_existed_check"],
                    last_modified=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    create_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )
            )
        except:
            g.babyweb.rollback()
        else:
            g.babyweb.commit()
            return stringToJson(status_code=201, message='Created')

        return stringToJson(status_code=400, message='Bad Request')
