"""
The MIT License

Copyright (c) 2023

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""
import os
from lxml import etree
from io import StringIO, BytesIO

from customException import CustomException
from utility.fileUtility import FILE_FORMAT


class XMLUtilities:
    def __init__(self):
        self.rss = None

    def get_xml(self):
        if self.rss is not None:
            return self.rss

        return self.get_default_xml()

    def get_default_xml(self):
        try:
            RSS_FORMAT = """<?xml version="1.0" ?>
            <todo>
                <author>User Name</author>
                <uuid>User Unique Identify ID</uuid>
                <todo_title>To-Do Title</todo_title>
                <todo_uid>To-Do Unique Identify ID</todo_uid>
                <todo_description>To-Do Description</todo_description>
                <list>
                    <checklist id="1">To-Do Checklist 1</checklist>
                    <checklist id="2">To-Do Checklist 2</checklist>
                    <checklist id="3">To-Do Checklist 3</checklist>
                </list>
                <last_modified>To-Do Last Modified Time</last_modified>
                <create_time>To-Do Created Time</create_time>
                <file>
                    <file_name>File Name</file_name>
                    <file_uid>File Unique Identify ID</file_uid>
                    <file_description>File Description</file_description>
                    <file_preview>File Preview</file_preview>
                    <file_create_time>File Created Time</file_create_time>
                </file>
            </todo>
            """

            parse = etree.XMLParser(encoding='utf8')
            root = etree.parse(StringIO(RSS_FORMAT), parse)

            self.rss = etree.tostring(root, encoding='utf8', xml_declaration=False)

            if self.rss is None:
                raise CustomException(error_message="XML Parsing ERROR")

            return self.rss

        except:
            return e

    @staticmethod
    def upload_file_preview_or_app(filename: str, uuid: str, todo_uid: str):
        try:
            with open(FILE_FORMAT.FILE_PATH + f"{uuid}/{todo_uid}/" + filename, "r") as f:
                fileData = f.read()

            if filename == "docProps/app.xml":
                fileData = fileData[fileData.find("\n"):]

                parse = etree.XMLParser(encoding='utf8', attribute_defaults=True, ns_clean=True, recover=True, dtd_validation=False, load_dtd=False, no_network=False,
                                        resolve_entities=True)
                root = etree.parse(StringIO(fileData), parse)
                fileData = etree.tostring(root, encoding='utf8', xml_declaration=False)

            return fileData
        except:
            return "None"

    def text2xml(self, data: dict):
        checklist: list = ["", "", ""]
        try:
            if data["list"] != ",,":
                checklist = data["list"].split(",")

            file_type: str = os.path.splitext(data["file_name"])[1]
            if file_type == ".txt":
                preview = self.upload_file_preview_or_app(filename=data["file_name"], uuid=data["uuid"], todo_uid=data["todo_uid"])
                if preview is None:
                    preview = "None"
            else:
                preview = self.upload_file_preview_or_app(filename="docProps/app.xml", uuid=data["uuid"], todo_uid=data["todo_uid"])

                if preview is None:
                    preview = "None"

            RSS_FORMAT = f"""<?xml version="1.0" ?>
            <todo>
                <author>{data["author"]}</author>
                <uuid>{data["uuid"]}</uuid>
                <todo_title>{data["todo_title"]}</todo_title>
                <todo_uid>{data["todo_uid"]}</todo_uid>
                <todo_description>{data["todo_description"]}</todo_description>
                <list>
                    <checklist id="1">{checklist[0]}</checklist>
                    <checklist id="2">{checklist[1]}</checklist>
                    <checklist id="3">{checklist[2]}</checklist>
                </list>
                <last_modified>{data["last_modified"]}</last_modified>
                <create_time>{data["create_time"].strftime("%Y-%m-%d %H:%M:%s")}</create_time>
                <file>
                    <file_name>{data["file_name"]}</file_name>
                    <file_uid>{data["file_uid"]}</file_uid>
                    <file_description>{data["file_description"]}</file_description>
                    <file_preview>{preview if file_type == ".txt" else "None"}</file_preview>
                    <file_create_time>{data["file_create_time"].strftime("%Y-%m-%d %H:%M:%s")}</file_create_time>

                </file>
            </todo>
            """

            parse = etree.XMLParser(encoding='utf8', attribute_defaults=True, ns_clean=True, recover=True, dtd_validation=False, load_dtd=False, no_network=False,
                                    resolve_entities=True)
            root = etree.parse(StringIO(RSS_FORMAT), parse)
            self.rss = etree.tostring(root, encoding='utf8', xml_declaration=False)

            if file_type == ".zip":
                root = etree.fromstring(self.rss, parse)
                file_app = root.find("file")
                file_app.append(etree.XML(f"<file_app>{preview.decode() if type(preview) == bytes else preview}</file_app>"))
                self.rss = etree.tostring(root, encoding='utf8', xml_declaration=False)
            elif file_type == ".txt":
                pass
            else:
                self.rss = None

        except:
            self.rss = None
