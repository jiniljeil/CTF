import os, dotenv
from datetime import timedelta

dotenv.load_dotenv()


class defaultConfig(object):
    """
        Configurations for FLASK Application
    """
    DEBUG = False
    TESTING = False

    SECRET_KEY = os.urandom(32)
    SESSION_COOKIE_NAME = 'session'
    SESSION_COOKIE_PATH = '/'
    SESSION_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = timedelta(seconds=300)
    MAX_CONTENT_LENGTH = 1000 * 1000

    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class devConfig(defaultConfig):
    """
        Configurations in Dev Environment
    """
    DEBUG = True
    TESTING = True

    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{os.environ.get("username")}:{os.environ.get("password")}@{os.environ.get("localip")}:{os.environ.get("localport")}/ToDoService?charset=utf8'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class productConfig(defaultConfig):
    """
        Configurations in Production Environment
    """
    DEBUG = False
    TESTING = False

    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{os.environ.get("username")}:{os.environ.get("password")}@{os.environ.get("localip")}:{os.environ.get("localport")}/ToDoService?charset=utf8'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
