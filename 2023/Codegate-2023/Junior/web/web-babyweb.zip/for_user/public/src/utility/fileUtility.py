import os, dotenv, re, unicodedata

dotenv.load_dotenv()


class FILE_FORMAT:
    FILE_PATH = os.environ.get("file_path")
    ALLOW_FILE_MIMETYPE = [".zip", ".txt"]
    ALLOW_FILE_MIME = ["application/octet-stream", "application/zip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Microsoft OOXML", "text/plain"]


class FileValidation:
    def __init__(self, uuid: str, todo_uid: str, filename: str):
        self.uuid = uuid
        self.todo_uid = todo_uid
        self.filename = filename

    def get_custom_filename(self):
        return self.filename

    def custom_secure_filename(self) -> str:
        _filename_ascii_strip_re = re.compile(r"[^A-Za-z0-9_.-]")

        filename = unicodedata.normalize("NFKD", self.filename)
        filename = filename.encode("ascii", "ignore").decode("ascii")

        for sep in os.sep, os.path.altsep:
            if sep:
                filename = filename.replace(sep, " ")
        filename = str(_filename_ascii_strip_re.sub("", "_".join(filename.split()))).strip(
            "._"
        )

        if (
                os.name == "nt"
                and filename
                and filename.split(".")[0].upper() in _windows_device_files
        ):
            filename = f"_{filename}"

        self.filename = filename
