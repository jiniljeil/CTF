from flask import g
from time import time
from base64 import b64encode, b64decode
from uuid import uuid5, NAMESPACE_URL
from datetime import datetime
from hashlib import sha256

from utility.models import userModel
from utility.httpUtility import stringToJson
from utility.customException import CustomException


class UserHandler(object):
    def __init__(self):
        self.selectData = None
        self.insertData = None

    def get_user_by_account_info(self, Authorization: bytes) -> stringToJson:
        try:
            username, password = tuple(b64decode(Authorization).decode().strip().split(","))
            password = b64encode(sha256(password.encode()).hexdigest().encode()).decode()

            self.selectData = g.babyweb.query(
                userModel.username, userModel.password, userModel.uuid
            ).filter(
                userModel.username == username, userModel.password == password
            ).first()

            if self.selectData is not None:
                return stringToJson(status_code=200, message='OK', data=self.selectData[2] if self.selectData[2] != "" else "none")
            else:
                raise CustomException(error_message="Bad Request")
        except:
            g.babyweb.rollback()

        return stringToJson(status_code=400, message='Bad Request')

    def create_user(self, Authorization: bytes) -> stringToJson:
        try:
            self.insertData = tuple(b64decode(Authorization).decode().strip().split(","))
            self.selectData = g.babyweb.query(userModel.username).filter(userModel.username == self.insertData[0]).count()

            if self.selectData > 0:
                raise CustomException(error_message="Bad Request")

            self.insertData += (str(uuid5(namespace=NAMESPACE_URL, name=self.insertData[0] + str(time()))),)

            g.babyweb.add(
                userModel(
                    uuid=self.insertData[2],
                    username=self.insertData[0],
                    password=b64encode(sha256(self.insertData[1].encode()).hexdigest().encode()).decode(),
                    last_login=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    create_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )
            )
        except Exception as e:
            print("error", e, flush=True)
            g.babyweb.rollback()
        else:
            g.babyweb.commit()
            return stringToJson(status_code=201, message='Created')


        return stringToJson(status_code=400, message='Bad Request')
