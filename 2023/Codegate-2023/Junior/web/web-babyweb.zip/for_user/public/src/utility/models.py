from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

ToDoDB = SQLAlchemy()


class userModel(ToDoDB.Model):
    __tablename__ = 'user'

    id = ToDoDB.Column(ToDoDB.Integer, primary_key=True, autoincrement=True)
    uuid = ToDoDB.Column(ToDoDB.String, nullable=True, unique=True)
    username = ToDoDB.Column(ToDoDB.String, nullable=False)
    password = ToDoDB.Column(ToDoDB.String, nullable=False)
    last_login = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)
    create_time = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)

    def __init__(self, uuid, username, password, last_login, **kwargs):
        self.uuid = uuid
        self.username = username
        self.password = password
        self.last_login = last_login

    def __repr__(self):
        return f"<user('{self.uuid}', '{self.username}', '{self.password}', '{self.last_login}')>"


class todoModel(ToDoDB.Model):
    __tablename__ = 'todo'

    id = ToDoDB.Column(ToDoDB.Integer, primary_key=True, autoincrement=True)
    uuid = ToDoDB.Column(ToDoDB.String, nullable=False)
    todo_uid = ToDoDB.Column(ToDoDB.String, nullable=True, unique=True)
    file_uid = ToDoDB.Column(ToDoDB.String, nullable=True)
    title = ToDoDB.Column(ToDoDB.String, nullable=False)
    description = ToDoDB.Column(ToDoDB.String, nullable=False)
    checklist = ToDoDB.Column(ToDoDB.String, nullable=False)
    file_existed_check = ToDoDB.Column(ToDoDB.Integer, default=0)
    last_modified = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)
    create_time = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)

    def __init__(self, uuid, todo_uid, file_uid, title, description, checklist, file_existed_check, last_modified, **kwargs):
        self.uuid = uuid
        self.todo_uid = todo_uid
        self.file_uid = file_uid
        self.title = title
        self.description = description
        self.checklist = checklist
        self.file_existed_check = file_existed_check
        self.last_modified = last_modified

    def __repr__(self):
        return f"<todo('{self.uuid}', '{self.todo_uid}', '{self.file_uid}', '{self.title}', '{self.description}', '{self.checklist}', '{self.file_existed_check}', '{self.last_modified}')>"


class fileModel(ToDoDB.Model):
    __tablename__ = 'file'

    id = ToDoDB.Column(ToDoDB.Integer, primary_key=True, autoincrement=True)
    uuid = ToDoDB.Column(ToDoDB.String, nullable=False)
    todo_uid = ToDoDB.Column(ToDoDB.String, nullable=False)
    file_uid = ToDoDB.Column(ToDoDB.String, nullable=True, unique=True)
    filename = ToDoDB.Column(ToDoDB.String, nullable=False)
    description = ToDoDB.Column(ToDoDB.String, nullable=False)
    path = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)
    create_time = ToDoDB.Column(ToDoDB.TIMESTAMP, nullable=False)

    def __init__(self, uuid, todo_uid, file_uid, filename, description, path, **kwargs):
        self.uuid = uuid
        self.todo_uid = todo_uid
        self.file_uid = file_uid
        self.filename = filename
        self.description = description
        self.path = path

    def __repr__(self):
        return f"<file('{self.uuid}', '{self.todo_uid}', '{self.file_uid}', '{self.filename}', '{self.description}', '{self.path}')>"
