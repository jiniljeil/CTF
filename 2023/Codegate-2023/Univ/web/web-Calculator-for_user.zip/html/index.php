<?php
	include('./config.php');

	render_page('index');
?>