<?php
	$dbcon = mysqli_connect("db", "codegate", "codegate111!", "codegate");
?>