<?php
	if(!defined('__MAIN__')) exit('!^_^!');

	include(__TEMPLATE__ . 'head.php');

?>
	<main role="main" class="container">
		<div class="jumbotron">
			<h1>Calculator</h1>
			<p class="lead">Calculator</p>
		</div>
	</main>
<?php
	include(__TEMPLATE__ . 'tail.php');
?>