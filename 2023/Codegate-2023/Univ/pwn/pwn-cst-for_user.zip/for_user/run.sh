#!/bin/bash

cd /home/ctf/
timeout 60 python3 wrapper.py