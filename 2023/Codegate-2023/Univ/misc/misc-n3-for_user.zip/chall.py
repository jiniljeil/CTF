import onnxruntime as ort # onnxruntime==1.15.0
import numpy as np # numpy==1.24.1
from PIL import Image # pillow==9.3.0
ort.set_default_logger_severity(3)

img = Image.open('input.png').convert('RGB')
x = np.array(img).transpose((2,0,1)).astype(np.float32)
x = np.expand_dims(x,axis=0)
outputs, = ort.InferenceSession('net.onnx').run(None, {'input': x})
print(bytes(outputs).decode('u8'))