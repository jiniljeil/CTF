export type IIdentifier = {
	type: string;
	name: string;
	value: string;
};
