export type IIcon = {
	type: string;
	mediaType?: string;
	url?: string;
};
